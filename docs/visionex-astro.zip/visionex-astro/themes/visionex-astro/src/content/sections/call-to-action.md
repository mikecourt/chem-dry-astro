---
enable: true
title: "Ready to meet your personal AI writing assistant?"
description: "Take action now to make a difference! Whether it's supporting a cause you're passionate about"
button:
  enable: true
  label: "Start writing for free"
  link: "#"
---
