---
title: "A Dynamic Team."
meta_title: "Our Team"
description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem has been the industry's standard dummy text ever since"

members:
  - name: "Terry Henderson"
    designation: "Product Marketer"
    image: "/images/team/terry.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Grace Turner"
    designation: "UI Designer"
    image: "/images/team/grace.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Ethan Mitchell"
    designation: "Java Engineer"
    image: "/images/team/ethan.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Ava Reynolds"
    designation: "Developer"
    image: "/images/team/ava.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Sophia Parker"
    designation: "Developer"
    image: "/images/team/sophia.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Noah Anderson"
    designation: "Java Engineer"
    image: "/images/team/noah.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Olivia Harper"
    designation: "UI Designer"
    image: "/images/team/olivia.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Benjamin Clarke"
    designation: "Product Marketer"
    image: "/images/team/ben.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Liam Sullivan"
    designation: "Product Marketer"
    image: "/images/team/sophia.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Chloe Bennett"
    designation: "UI/UX designer"
    image: "/images/team/noah.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Samuel Foster"
    designation: "Developer"
    image: "/images/team/olivia.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"

  - name: "Joseph Barnes"
    designation: "Java Engineer"
    image: "/images/team/ben.png"
    social:
      - name: "facebook"
        icon: "FaFacebook"
        link: "https://www.facebook.com/"

      - name: "twitter"
        icon: "FaTwitter"
        link: "https://twitter.com/"

      - name: "github"
        icon: "FaGithub"
        link: "https://www.github.com/"

      - name: "linkedin"
        icon: "FaLinkedin"
        link: "https://www.linkedin.com/"
---
